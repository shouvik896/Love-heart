LOVE HEART WEBSITE

Files:
- index.html (the complete website)

Publish free with GitHub Pages:
1. Sign in at https://github.com
2. Create a new public repository (example: love-heart)
3. Upload index.html to the repository root and commit.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait a minute and open the URL shown in Settings > Pages:
   https://YOUR-USERNAME.github.io/love-heart/

This is a static HTML site; no Python/Pygame installation is needed for visitors.
